'''
Main.py
'''

def get_version() -> str:
    return "0.1.0"

if __name__ == '__main__':
    print("current version is: " + get_version())
